// MuninNodeSettings.cpp : implementation file
//

#include "StdAfx.h"
#include "MuninNodeSettings.h"

// MuninNodeSettings

CIniFile g_Config;
