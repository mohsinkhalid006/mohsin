#pragma once

#include "../extra/iniFile.h"
#include "TString.h"

extern CIniFile g_Config;
